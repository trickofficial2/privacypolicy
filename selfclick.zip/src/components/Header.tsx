import React from 'react';
import { 
  Bot, 
  PlusCircle, 
  Layers, 
  Terminal, 
  Send, 
  Volume2, 
  VolumeX, 
  User, 
  Sparkles,
  FolderDown
} from 'lucide-react';
import { BotSettings, TelegramUser } from '../types';

interface HeaderProps {
  activeTab: 'dashboard' | 'generator' | 'sandbox' | 'bot_setup' | 'profile';
  setActiveTab: (tab: 'dashboard' | 'generator' | 'sandbox' | 'bot_setup' | 'profile') => void;
  settings: BotSettings;
  updateSettings: (newSettings: Partial<BotSettings>) => void;
  isTelegramWebApp: boolean;
  activeRunnersCount: number;
  user: TelegramUser;
  onOpenExportModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  settings,
  updateSettings,
  isTelegramWebApp,
  activeRunnersCount,
  user,
  onOpenExportModal,
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-40">
      {/* Top micro-bar */}
      <div className="max-w-7xl mx-auto px-4 py-1.5 flex items-center justify-between text-xs text-slate-400 border-b border-slate-800/60">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            {isTelegramWebApp ? '✈️ Telegram Mini App' : '🌐 Web Dashboard'}
          </span>
          <span className="hidden sm:inline text-slate-500">•</span>
          <span className="hidden sm:inline text-slate-400 font-mono">
            ID: {user.id} ({user.firstName})
          </span>
        </div>

        <div className="flex items-center gap-3">
          {activeRunnersCount > 0 && (
            <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>{activeRunnersCount} Running</span>
            </div>
          )}

          {/* Export & Download Shortcut */}
          <button
            onClick={onOpenExportModal}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition text-[11px] font-medium"
            title="Download bot scripts or export data"
          >
            <FolderDown className="w-3 h-3 text-cyan-400" />
            <span className="hidden sm:inline">Export</span>
          </button>

          {/* Sound toggle */}
          <button
            id="btn-sound-toggle"
            onClick={() => updateSettings({ soundEnabled: !settings.soundEnabled })}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
            title={settings.soundEnabled ? 'Mute sound' : 'Unmute sound'}
          >
            {settings.soundEnabled ? (
              <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
            ) : (
              <VolumeX className="w-3.5 h-3.5 text-slate-500" />
            )}
          </button>

          {/* User Profile Pill */}
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex items-center gap-1.5 px-2 py-0.5 rounded-lg border transition text-[11px] ${
              activeTab === 'profile'
                ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-300'
                : 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:bg-slate-700'
            }`}
          >
            {user.photoUrl ? (
              <img
                src={user.photoUrl}
                alt={user.firstName}
                referrerPolicy="no-referrer"
                className="w-4 h-4 rounded-full object-cover"
              />
            ) : (
              <User className="w-3 h-3 text-cyan-400" />
            )}
            <span className="font-semibold max-w-[90px] truncate">{user.firstName}</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white border border-cyan-400/30">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold text-white tracking-tight">
                SelfClick Bot
              </h1>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono font-medium border border-blue-500/30">
                Pro
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Automated Self-Clicking for Monetag, Gigapub & Direct Links
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <nav className="flex items-center gap-1.5 bg-slate-950/70 p-1 rounded-xl border border-slate-800 overflow-x-auto">
          <button
            id="tab-dashboard"
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              activeTab === 'dashboard'
                ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Dashboard</span>
          </button>

          <button
            id="tab-generator"
            onClick={() => setActiveTab('generator')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              activeTab === 'generator'
                ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>New Package</span>
          </button>

          <button
            id="tab-sandbox"
            onClick={() => setActiveTab('sandbox')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              activeTab === 'sandbox'
                ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Live Logs</span>
          </button>

          <button
            id="tab-bot-setup"
            onClick={() => setActiveTab('bot_setup')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              activeTab === 'bot_setup'
                ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Send className="w-4 h-4 text-sky-400" />
            <span>Bot Setup</span>
          </button>

          <button
            id="tab-profile"
            onClick={() => setActiveTab('profile')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
              activeTab === 'profile'
                ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <User className="w-4 h-4 text-emerald-400" />
            <span>Profile</span>
          </button>
        </nav>

        {/* Quick CTA */}
        <button
          id="btn-quick-new-package"
          onClick={() => setActiveTab('generator')}
          className="hidden md:flex items-center gap-2 px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-md shadow-emerald-700/20 transition-all cursor-pointer active:scale-95"
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Package</span>
        </button>
      </div>
    </header>
  );
};
