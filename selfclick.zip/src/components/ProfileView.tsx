import React, { useState } from 'react';
import { 
  User, 
  ShieldCheck, 
  Calendar, 
  Hash, 
  AtSign, 
  Sparkles, 
  Copy, 
  Check, 
  Lock, 
  Globe, 
  Info, 
  Layers, 
  MousePointerClick, 
  DollarSign,
  UserPlus,
  RefreshCw
} from 'lucide-react';
import { TelegramUser, AdPackage } from '../types';
import { saveCurrentUser } from '../utils/telegram';

interface ProfileViewProps {
  user: TelegramUser;
  onUpdateUser: (newUser: TelegramUser) => void;
  userPackages: AdPackage[];
  cpmRate: number;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  onUpdateUser,
  userPackages,
  cpmRate,
}) => {
  const [copiedId, setCopiedId] = useState(false);
  const [showSwitchModal, setShowSwitchModal] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customUsername, setCustomUsername] = useState('');
  const [customId, setCustomId] = useState('');

  const totalClicks = userPackages.reduce((sum, p) => sum + p.completedClicks, 0);
  const activeCount = userPackages.filter((p) => p.status === 'running').length;
  const estimatedEarnings = ((totalClicks / 1000) * cpmRate).toFixed(3);

  const handleCopyId = () => {
    navigator.clipboard.writeText(user.id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleSwitchToSimulatedUser = (name: string, username: string, id: string, photoUrl?: string) => {
    const newUser: TelegramUser = {
      id,
      firstName: name,
      username,
      photoUrl,
      languageCode: 'en',
      isPremium: true,
      joinedAt: new Date().toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      }),
      joinedTimestamp: Date.now(),
    };
    saveCurrentUser(newUser);
    onUpdateUser(newUser);
    setShowSwitchModal(false);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Profile Card */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        {/* Background accent glow */}
        <div className="absolute -right-20 -top-20 w-60 h-60 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 relative z-10">
          {/* Avatar */}
          <div className="relative">
            {user.photoUrl ? (
              <img
                src={user.photoUrl}
                alt={user.firstName}
                referrerPolicy="no-referrer"
                className="w-24 h-24 rounded-2xl object-cover border-2 border-cyan-400 shadow-xl shadow-cyan-500/20"
              />
            ) : (
              <div className="w-24 h-24 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white text-3xl font-extrabold shadow-xl border-2 border-cyan-400">
                {user.firstName.charAt(0).toUpperCase()}
              </div>
            )}
            {user.isPremium && (
              <div className="absolute -bottom-2 -right-2 bg-gradient-to-r from-amber-400 to-amber-600 text-slate-950 p-1.5 rounded-full shadow-lg" title="Telegram Premium User">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
            )}
          </div>

          {/* User Details */}
          <div className="flex-1 text-center sm:text-left space-y-1.5">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h2 className="text-2xl font-bold text-white tracking-tight">
                {user.firstName} {user.lastName || ''}
              </h2>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Verified Account</span>
              </span>
            </div>

            {user.username && (
              <p className="text-sm font-medium text-cyan-400 flex items-center justify-center sm:justify-start gap-1 font-mono">
                <AtSign className="w-3.5 h-3.5" />
                <span>{user.username.replace('@', '')}</span>
              </p>
            )}

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 text-xs text-slate-400 pt-2">
              <div className="flex items-center gap-1.5 bg-slate-950/70 px-3 py-1.5 rounded-lg border border-slate-800">
                <Hash className="w-3.5 h-3.5 text-slate-500" />
                <span className="font-mono text-slate-300">ID: {user.id}</span>
                <button
                  onClick={handleCopyId}
                  className="ml-1 text-slate-400 hover:text-cyan-400 transition"
                  title="Copy Telegram ID"
                >
                  {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <div className="flex items-center gap-1.5 bg-slate-950/70 px-3 py-1.5 rounded-lg border border-slate-800">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>Joined: <strong className="text-slate-200">{user.joinedAt}</strong></span>
              </div>

              <div className="flex items-center gap-1.5 bg-slate-950/70 px-3 py-1.5 rounded-lg border border-slate-800">
                <Globe className="w-3.5 h-3.5 text-purple-400" />
                <span>Lang: <strong className="text-slate-200 uppercase">{user.languageCode || 'EN'}</strong></span>
              </div>
            </div>
          </div>

          {/* Test Account Switcher Button */}
          <div>
            <button
              id="btn-switch-account-test"
              onClick={() => setShowSwitchModal(true)}
              className="text-xs px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl font-medium border border-slate-700 transition flex items-center gap-1.5 shadow"
            >
              <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
              <span>Test Another Account</span>
            </button>
          </div>
        </div>

        {/* Data Privacy Status Banner */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <Lock className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>
              <strong>Private Account Isolation:</strong> All your packages and click data are tied strictly to Telegram User ID <code className="text-cyan-400 font-mono font-bold">{user.id}</code>. Other users can never view or modify your packages.
            </span>
          </div>
        </div>
      </div>

      {/* Account Performance Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="text-slate-500 text-xs flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>My Packages</span>
          </div>
          <div className="mt-2 text-2xl font-bold text-white font-mono">
            {userPackages.length}
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Total Created</p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="text-slate-500 text-xs flex items-center gap-1.5">
            <MousePointerClick className="w-3.5 h-3.5 text-emerald-400" />
            <span>Executed Clicks</span>
          </div>
          <div className="mt-2 text-2xl font-bold text-emerald-400 font-mono">
            {totalClicks}
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Completed self clicks</p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="text-slate-500 text-xs flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span>Active Tasks</span>
          </div>
          <div className="mt-2 text-2xl font-bold text-white font-mono">
            {activeCount}
          </div>
          <p className="text-[10px] text-slate-500 mt-1">Currently running</p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="text-slate-500 text-xs flex items-center gap-1.5">
            <DollarSign className="w-3.5 h-3.5 text-amber-400" />
            <span>Est. Revenue</span>
          </div>
          <div className="mt-2 text-2xl font-bold text-amber-400 font-mono">
            ${estimatedEarnings}
          </div>
          <p className="text-[10px] text-slate-500 mt-1">CPM @ ${cpmRate.toFixed(2)}</p>
        </div>
      </div>

      {/* Developer FAQ: User Data Collection Explanation */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Info className="w-4 h-4 text-cyan-400" />
          <span>How Telegram User Data Collection Works</span>
        </h3>

        <div className="text-xs text-slate-300 leading-relaxed space-y-2">
          <p>
            <strong>Do you need to provide anything or configure extra bot permissions?</strong><br />
            <span className="text-emerald-400 font-semibold">No additional bot configuration or credentials are required!</span> When any user opens this Mini App inside Telegram, Telegram's native client automatically injects the user's information through the secure <code className="text-cyan-300 bg-slate-950 px-1 py-0.5 rounded font-mono">window.Telegram.WebApp.initDataUnsafe.user</code> object.
          </p>
          <ul className="list-disc list-inside space-y-1 text-slate-400 pl-2">
            <li><strong>Full Name:</strong> Automatically read from Telegram profile (<code className="text-slate-300">first_name</code> and <code className="text-slate-300">last_name</code>).</li>
            <li><strong>Profile Picture:</strong> Automatically received from Telegram CDN (<code className="text-slate-300">photo_url</code>).</li>
            <li><strong>Telegram User ID:</strong> Unique numeric Telegram ID (<code className="text-slate-300">id</code>) used to guarantee data privacy.</li>
            <li><strong>Telegram Username:</strong> Public handle (<code className="text-slate-300">username</code>) if set by the user.</li>
            <li><strong>Join Date:</strong> Automatically stamped when the user first opens your bot.</li>
          </ul>
        </div>
      </div>

      {/* Switch Account Modal for Browser Testing */}
      {showSwitchModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-cyan-400" />
              <span>Test Account Switcher</span>
            </h3>
            <p className="text-xs text-slate-400">
              Switch between simulated Telegram accounts to verify that each user only sees their own private packages and logs.
            </p>

            <div className="space-y-2">
              <button
                onClick={() => handleSwitchToSimulatedUser('Alex Rider', '@alex_traffic', '689210452', 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80')}
                className="w-full text-left p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 transition flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-white text-xs">User #1: Alex Rider</div>
                  <div className="text-[11px] text-cyan-400 font-mono">ID: 689210452 (@alex_traffic)</div>
                </div>
                {user.id === '689210452' && <Check className="w-4 h-4 text-emerald-400" />}
              </button>

              <button
                onClick={() => handleSwitchToSimulatedUser('Sarah Jenkins', '@sarah_ads', '794102941', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80')}
                className="w-full text-left p-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 transition flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-white text-xs">User #2: Sarah Jenkins</div>
                  <div className="text-[11px] text-cyan-400 font-mono">ID: 794102941 (@sarah_ads)</div>
                </div>
                {user.id === '794102941' && <Check className="w-4 h-4 text-emerald-400" />}
              </button>
            </div>

            <div className="pt-2 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowSwitchModal(false)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
