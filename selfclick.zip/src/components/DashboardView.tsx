import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Trash2, 
  PlusCircle, 
  ExternalLink, 
  Zap, 
  CheckCircle, 
  Clock, 
  Layers, 
  Eye, 
  Copy,
  DollarSign,
  Activity,
  MousePointerClick,
  User
} from 'lucide-react';
import { AdPackage, BotSettings, TelegramUser } from '../types';

interface DashboardViewProps {
  packages: AdPackage[];
  user: TelegramUser;
  onStartPackage: (pkgId: string) => void;
  onPausePackage: (pkgId: string) => void;
  onResetPackage: (pkgId: string) => void;
  onDeletePackage: (pkgId: string) => void;
  onTestSingleClick: (pkg: AdPackage) => void;
  onNavigateToGenerator: () => void;
  onNavigateToSandbox: () => void;
  onOpenExportModal: () => void;
  settings: BotSettings;
  activePackageId: string | null;
  countdownSeconds: number;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  packages,
  user,
  onStartPackage,
  onPausePackage,
  onResetPackage,
  onDeletePackage,
  onTestSingleClick,
  onNavigateToGenerator,
  onNavigateToSandbox,
  onOpenExportModal,
  settings,
  activePackageId,
  countdownSeconds,
}) => {
  const [filter, setFilter] = useState<'all' | 'monetag' | 'gigapub' | 'direct_link' | 'active'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Filter packages
  const filteredPackages = packages.filter((pkg) => {
    if (filter === 'active') return pkg.status === 'running';
    if (filter === 'monetag') return pkg.network === 'monetag';
    if (filter === 'gigapub') return pkg.network === 'gigapub';
    if (filter === 'direct_link') return pkg.network === 'direct_link';
    return true;
  });

  // Calculate aggregated stats
  const totalCompletedClicks = packages.reduce((acc, p) => acc + p.completedClicks, 0);
  const activeCount = packages.filter((p) => p.status === 'running').length;
  const estimatedRevenue = ((totalCompletedClicks / 1000) * settings.cpmRate).toFixed(3);

  const handleCopyLink = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Top Welcome / User Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-gradient-to-r from-slate-900 to-slate-900/60 border border-slate-800 p-4 rounded-2xl">
        <div className="flex items-center gap-3">
          {user.photoUrl ? (
            <img
              src={user.photoUrl}
              alt={user.firstName}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-xl object-cover border border-cyan-400/40"
            />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-cyan-600 flex items-center justify-center text-white font-bold text-base">
              {user.firstName.charAt(0).toUpperCase()}
            </div>
          )}
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-tight">
                Welcome, {user.firstName}!
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                Private Dashboard
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Telegram ID: {user.id} • {user.username || 'Personal Account'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenExportModal}
            className="text-xs px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition flex items-center gap-1.5 font-medium"
          >
            <span>Export & Download</span>
          </button>
        </div>
      </div>

      {/* Top Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Metric 1: Total Packages */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">My Packages</span>
            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
              {packages.length}
            </span>
            <span className="text-xs text-slate-500 font-medium">packages</span>
          </div>
          <div className="mt-2 text-[11px] text-cyan-400">
            {packages.filter(p => p.network === 'monetag').length} Monetag • {packages.filter(p => p.network === 'gigapub').length} Gigapub • {packages.filter(p => p.network === 'direct_link').length} Direct
          </div>
        </div>

        {/* Metric 2: Completed Clicks */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Executed Clicks</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
              <MousePointerClick className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono">
              {totalCompletedClicks}
            </span>
            <span className="text-xs text-slate-500 font-medium">clicks finished</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-500 flex items-center gap-1 font-medium">
            <Activity className="w-3 h-3" />
            <span>Automated loop tracking</span>
          </div>
        </div>

        {/* Metric 3: Active Tasks */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Active Tasks</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
              {activeCount}
            </span>
            <span className="text-xs text-slate-500 font-medium">running</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            {activeCount > 0 ? (
              <span className="text-emerald-400 font-semibold animate-pulse">● Self-clicks running</span>
            ) : (
              <span>Click Start on any package</span>
            )}
          </div>
        </div>

        {/* Metric 4: Estimated CPM */}
        <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Est. Revenue</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono">
              ${estimatedRevenue}
            </span>
            <span className="text-xs text-slate-500 font-medium">USD</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            CPM Rate: ${settings.cpmRate.toFixed(2)} / 1K
          </div>
        </div>
      </div>

      {/* Control Bar & Filter Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
          <button
            id="filter-all"
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
              filter === 'all'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            All ({packages.length})
          </button>
          <button
            id="filter-monetag"
            onClick={() => setFilter('monetag')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
              filter === 'monetag'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            Monetag ({packages.filter(p => p.network === 'monetag').length})
          </button>
          <button
            id="filter-gigapub"
            onClick={() => setFilter('gigapub')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
              filter === 'gigapub'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            Gigapub ({packages.filter(p => p.network === 'gigapub').length})
          </button>
          <button
            id="filter-direct"
            onClick={() => setFilter('direct_link')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
              filter === 'direct_link'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            Direct Link ({packages.filter(p => p.network === 'direct_link').length})
          </button>
          {activeCount > 0 && (
            <button
              id="filter-active"
              onClick={() => setFilter('active')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                filter === 'active'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                  : 'text-emerald-400 hover:bg-emerald-500/10'
              }`}
            >
              Running Only ({activeCount})
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onNavigateToSandbox}
            className="text-xs text-slate-300 hover:text-white px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 flex items-center gap-1.5 transition"
          >
            <Eye className="w-3.5 h-3.5 text-cyan-400" />
            <span>Live Sandbox View</span>
          </button>

          <button
            id="btn-create-pkg-dash"
            onClick={onNavigateToGenerator}
            className="text-xs bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-3.5 py-1.5 rounded-lg flex items-center gap-1.5 shadow-md shadow-cyan-600/20 transition cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Create New Package</span>
          </button>
        </div>
      </div>

      {/* Package Cards List */}
      {filteredPackages.length === 0 ? (
        <div className="text-center py-16 px-4 bg-slate-900/40 border border-dashed border-slate-800 rounded-2xl">
          <div className="w-12 h-12 rounded-full bg-slate-800/80 flex items-center justify-center mx-auto text-slate-500 mb-3">
            <Layers className="w-6 h-6" />
          </div>
          <h3 className="text-slate-200 font-bold text-base mb-1">No Packages Created Yet</h3>
          <p className="text-slate-400 text-xs max-w-md mx-auto">
            You have no active ad packages in your personal account. Click the button below to configure your Monetag, Gigapub, or Direct Link ad package.
          </p>
          <button
            onClick={onNavigateToGenerator}
            className="mt-5 px-5 py-2.5 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-semibold rounded-xl shadow-lg transition inline-flex items-center gap-2 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Create Your First Package</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPackages.map((pkg) => {
            const isRunning = pkg.status === 'running';
            const isCompleted = pkg.completedClicks >= pkg.totalClicks;
            const progressPercent = Math.min(100, Math.round((pkg.completedClicks / pkg.totalClicks) * 100));
            const isThisActiveTimer = activePackageId === pkg.id;

            return (
              <div
                key={pkg.id}
                id={`pkg-card-${pkg.id}`}
                className={`bg-slate-900/90 border rounded-2xl p-5 shadow-lg transition-all relative flex flex-col justify-between ${
                  isRunning
                    ? 'border-cyan-400/80 ring-2 ring-cyan-500/20 shadow-cyan-500/10'
                    : isCompleted
                    ? 'border-emerald-500/40'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Header of Package Card */}
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2.5">
                    {/* Network Badge */}
                    <span
                      className={`text-[11px] font-bold px-2.5 py-0.5 rounded-md uppercase tracking-wider ${
                        pkg.network === 'monetag'
                          ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                          : pkg.network === 'gigapub'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}
                    >
                      {pkg.network === 'monetag' ? 'Monetag' : pkg.network === 'gigapub' ? 'Gigapub' : 'Direct Link'}
                    </span>

                    {/* Status Pill */}
                    <div className="flex items-center gap-1.5">
                      {isRunning && (
                        <span className="flex items-center gap-1 text-[11px] font-semibold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded-full border border-cyan-500/30">
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping"></span>
                          Running
                        </span>
                      )}
                      {!isRunning && isCompleted && (
                        <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
                          <CheckCircle className="w-3 h-3" />
                          Completed
                        </span>
                      )}
                      {!isRunning && !isCompleted && pkg.completedClicks > 0 && (
                        <span className="text-[11px] font-semibold text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-500/30">
                          Paused
                        </span>
                      )}
                      {!isRunning && pkg.completedClicks === 0 && (
                        <span className="text-[11px] font-medium text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded-full">
                          Ready to Run
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-white tracking-tight leading-snug line-clamp-1">
                    {pkg.name}
                  </h3>

                  {/* Ad ID / URL preview */}
                  <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-400 bg-slate-950/60 px-2.5 py-1.5 rounded-lg border border-slate-800/70">
                    <span className="font-mono text-cyan-300 truncate max-w-[200px]" title={pkg.adIdOrUrl}>
                      {pkg.adIdOrUrl}
                    </span>
                    <button
                      onClick={() => handleCopyLink(pkg.adIdOrUrl, pkg.id)}
                      className="ml-auto text-slate-400 hover:text-white transition"
                      title="Copy URL"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                    {copiedId === pkg.id && (
                      <span className="text-[10px] text-emerald-400 font-semibold">Copied!</span>
                    )}
                  </div>

                  {/* Interval & Config badges */}
                  <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-slate-950/40 p-2 rounded-lg border border-slate-800/60">
                      <span className="text-slate-500 block text-[10px] flex items-center gap-1">
                        <Clock className="w-3 h-3 text-cyan-400" />
                        <span>Interval</span>
                      </span>
                      <span className="font-bold text-slate-200 font-mono">
                        {pkg.intervalSeconds}s
                        {pkg.enableJitter && <span className="text-[10px] text-cyan-400 font-normal"> (±1s)</span>}
                      </span>
                    </div>

                    <div className="bg-slate-950/40 p-2 rounded-lg border border-slate-800/60">
                      <span className="text-slate-500 block text-[10px] flex items-center gap-1">
                        <Zap className="w-3 h-3 text-emerald-400" />
                        <span>Target Clicks</span>
                      </span>
                      <span className="font-bold text-slate-200 font-mono">
                        {pkg.totalClicks} times
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar & Counter */}
                  <div className="mt-4">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-slate-400 font-medium">Progress</span>
                      <span className="font-mono text-slate-200 font-bold">
                        {pkg.completedClicks} / {pkg.totalClicks} ({progressPercent}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isCompleted
                            ? 'bg-emerald-500'
                            : isRunning
                            ? 'bg-gradient-to-r from-cyan-500 to-blue-500 animate-pulse'
                            : 'bg-cyan-600'
                        }`}
                        style={{ width: `${progressPercent}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Next Click Countdown (If Running) */}
                  {isRunning && isThisActiveTimer && (
                    <div className="mt-3 p-2 rounded-lg bg-cyan-950/50 border border-cyan-500/30 flex items-center justify-between text-xs">
                      <span className="text-cyan-300 flex items-center gap-1.5 font-medium">
                        <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
                        Next click in:
                      </span>
                      <span className="font-mono font-bold text-cyan-300 bg-cyan-900/60 px-2 py-0.5 rounded text-sm">
                        {countdownSeconds}s
                      </span>
                    </div>
                  )}
                </div>

                {/* Card Action Controls (Direct per User Intent) */}
                <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {/* Start / Pause Button */}
                    {isRunning ? (
                      <button
                        id={`btn-pause-${pkg.id}`}
                        onClick={() => onPausePackage(pkg.id)}
                        className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow transition cursor-pointer active:scale-95"
                      >
                        <Pause className="w-3.5 h-3.5" />
                        <span>Pause</span>
                      </button>
                    ) : (
                      <button
                        id={`btn-start-${pkg.id}`}
                        onClick={() => onStartPackage(pkg.id)}
                        className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/20 transition cursor-pointer active:scale-95"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>{pkg.completedClicks > 0 && !isCompleted ? 'Resume' : 'Start'}</span>
                      </button>
                    )}

                    {/* Quick Single Test Click Button */}
                    <button
                      id={`btn-test-click-${pkg.id}`}
                      onClick={() => onTestSingleClick(pkg)}
                      title="Test a single click right now"
                      className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium flex items-center gap-1 transition"
                    >
                      <Zap className="w-3 h-3 text-amber-400" />
                      <span className="hidden sm:inline">1x Test</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-1">
                    {/* Reset Button */}
                    <button
                      id={`btn-reset-${pkg.id}`}
                      onClick={() => onResetPackage(pkg.id)}
                      title="Reset click count to 0"
                      className="p-2 rounded-lg bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200 transition"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete Button (Can delete at any time) */}
                    <button
                      id={`btn-delete-${pkg.id}`}
                      onClick={() => onDeletePackage(pkg.id)}
                      title="Delete this package"
                      className="p-2 rounded-lg bg-slate-800/60 hover:bg-rose-950/60 text-slate-400 hover:text-rose-400 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
