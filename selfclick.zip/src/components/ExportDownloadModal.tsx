import React, { useState } from 'react';
import { 
  Download, 
  FileCode, 
  Database, 
  Check, 
  X, 
  Package, 
  FolderDown, 
  FileText,
  Copy
} from 'lucide-react';
import { AdPackage, ClickLog, TelegramUser, BotSettings } from '../types';

interface ExportDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: TelegramUser;
  packages: AdPackage[];
  logs: ClickLog[];
  settings: BotSettings;
}

export const ExportDownloadModal: React.FC<ExportDownloadModalProps> = ({
  isOpen,
  onClose,
  user,
  packages,
  logs,
  settings,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  if (!isOpen) return null;

  const webAppUrl = window.location.origin;

  const triggerDownload = (filename: string, content: string, mimeType: string = 'application/json') => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setDownloadSuccess(filename);
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handleExportDataJson = () => {
    const backupData = {
      exportedAt: new Date().toISOString(),
      user: {
        id: user.id,
        name: `${user.firstName} ${user.lastName || ''}`.trim(),
        username: user.username,
        joinedAt: user.joinedAt,
      },
      packages,
      logs,
      settings,
      stats: {
        totalPackages: packages.length,
        totalCompletedClicks: packages.reduce((acc, p) => acc + p.completedClicks, 0),
        estimatedCpmRevenue: ((packages.reduce((acc, p) => acc + p.completedClicks, 0) / 1000) * settings.cpmRate).toFixed(3),
      }
    };
    triggerDownload(`telegram_selfclick_backup_${user.id}_${Date.now()}.json`, JSON.stringify(backupData, null, 2));
  };

  const handleDownloadPythonBot = () => {
    const pythonCode = `# ==========================================================
# Telegram Self Click Bot - Production Ready Script
# Run: pip install python-telegram-bot
# ==========================================================
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

BOT_TOKEN = "${settings.botToken || 'PASTE_YOUR_TELEGRAM_BOT_TOKEN_HERE'}"
WEB_APP_URL = "${webAppUrl}"

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    keyboard = [
        [
            InlineKeyboardButton(
                text="🚀 Open Self Click Dashboard", 
                web_app=WebAppInfo(url=WEB_APP_URL)
            )
        ],
        [
            InlineKeyboardButton(text="⚡ Monetag Automation", callback_data="run_monetag"),
            InlineKeyboardButton(text="⚡ Gigapub Automation", callback_data="run_gigapub")
        ],
        [
            InlineKeyboardButton(text="⚡ Direct Link Clicks", callback_data="run_direct"),
            InlineKeyboardButton(text="📊 My Statistics", callback_data="stats")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome = (
        f"🤖 Hello {user.first_name}! Welcome to the Self Click Telegram Bot.\\n\\n"
        "Create custom packages for Monetag, Gigapub, and Direct Link ads with custom intervals and click counts.\\n\\n"
        "Tap the button below to launch your personal dashboard:"
    )
    await update.message.reply_text(welcome, reply_markup=reply_markup)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data in ["run_monetag", "run_gigapub", "run_direct"]:
        await query.edit_message_text(
            "⚡ **Package execution triggered!**\\nOpen dashboard to monitor live clicks.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text="Open Dashboard", web_app=WebAppInfo(url=WEB_APP_URL))]])
        )
    elif query.data == "stats":
        await query.edit_message_text(
            "📊 **Your Bot Statistics:**\\nStatus: Active\\nDashboard linked successfully.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text="Open Dashboard", web_app=WebAppInfo(url=WEB_APP_URL))]])
        )

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    print(f"Self Click Bot is running! Open WebApp: {WEB_APP_URL}")
    app.run_polling()

if __name__ == "__main__":
    main()
`;
    triggerDownload('bot.py', pythonCode, 'text/x-python');
  };

  const handleDownloadNodeBot = () => {
    const nodeCode = `// ==========================================================
// Telegram Self Click Bot - Node.js Telegraf Script
// Run: npm install telegraf
// ==========================================================
const { Telegraf, Markup } = require('telegraf');

const BOT_TOKEN = '${settings.botToken || 'PASTE_YOUR_TELEGRAM_BOT_TOKEN_HERE'}';
const WEB_APP_URL = '${webAppUrl}';

const bot = new Telegraf(BOT_TOKEN);

bot.start((ctx) => {
  const name = ctx.from.first_name || 'User';
  return ctx.reply(
    \`🤖 Welcome \${name} to the Self Click Telegram Bot!\\n\\nTap below to launch your personal automated dashboard:\`,
    Markup.inlineKeyboard([
      [Markup.button.webApp('🚀 Open Self Click Dashboard', WEB_APP_URL)],
      [
        Markup.button.callback('⚡ Monetag Clicks', 'run_monetag'),
        Markup.button.callback('⚡ Gigapub Clicks', 'run_gigapub')
      ],
      [
        Markup.button.callback('⚡ Direct Link Clicks', 'run_direct'),
        Markup.button.callback('📊 My Statistics', 'stats')
      ]
    ])
  );
});

bot.action('run_monetag', (ctx) => {
  ctx.answerCbQuery('Starting Monetag package...');
  ctx.reply('✅ Monetag package triggered! Open dashboard to monitor clicks.');
});

bot.action('stats', (ctx) => {
  ctx.answerCbQuery();
  ctx.reply('📊 Bot status: Active and connected to WebApp.');
});

bot.launch().then(() => {
  console.log(\`Self Click Bot active on Telegram! URL: \${WEB_APP_URL}\`);
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
`;
    triggerDownload('bot.js', nodeCode, 'text/javascript');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-xl w-full shadow-2xl space-y-5 relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>

        <div>
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <FolderDown className="w-6 h-6 text-cyan-400" />
            <span>Export & Download Files</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Download your packages, click history, or the complete Telegram Bot server scripts ready to deploy.
          </p>
        </div>

        {downloadSuccess && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>File downloaded successfully: {downloadSuccess}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Option 1: Export Personal Data JSON */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between space-y-3">
            <div>
              <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-2">
                <Database className="w-4 h-4" />
              </div>
              <h4 className="font-bold text-white text-sm">Account Data Backup</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                JSON export of your {packages.length} packages, {logs.length} execution logs, and account settings.
              </p>
            </div>
            <button
              onClick={handleExportDataJson}
              className="w-full py-2 px-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download data.json</span>
            </button>
          </div>

          {/* Option 2: Python Bot Script */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between space-y-3">
            <div>
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-2">
                <FileCode className="w-4 h-4" />
              </div>
              <h4 className="font-bold text-white text-sm">Python Bot Script</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                Complete python-telegram-bot script configured with your live WebApp URL.
              </p>
            </div>
            <button
              onClick={handleDownloadPythonBot}
              className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download bot.py</span>
            </button>
          </div>

          {/* Option 3: Node.js Bot Script */}
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between space-y-3 sm:col-span-2">
            <div className="flex items-start justify-between">
              <div>
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center mb-2">
                  <FileText className="w-4 h-4" />
                </div>
                <h4 className="font-bold text-white text-sm">Node.js (Telegraf) Bot Script</h4>
                <p className="text-[11px] text-slate-400 mt-1">
                  Ready-to-run JavaScript file for hosting on VPS, Railway, Render, or local machine.
                </p>
              </div>
              <button
                onClick={handleDownloadNodeBot}
                className="py-2 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition border border-slate-700"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download bot.js</span>
              </button>
            </div>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
