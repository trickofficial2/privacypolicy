import React, { useState } from 'react';
import { 
  Send, 
  Bot, 
  Copy, 
  Check, 
  ExternalLink, 
  Code2, 
  HelpCircle, 
  Key, 
  Layers, 
  Sparkles,
  ChevronRight,
  FolderDown
} from 'lucide-react';
import { BotSettings, AdPackage, TelegramUser } from '../types';

interface TelegramBotSetupProps {
  settings: BotSettings;
  updateSettings: (newSettings: Partial<BotSettings>) => void;
  packages: AdPackage[];
  user: TelegramUser;
  onStartPackage: (pkgId: string) => void;
  onNavigateToDashboard: () => void;
  onNavigateToGenerator: () => void;
  onOpenExportModal: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  buttons?: { text: string; action: string }[];
  timestamp: string;
}

export const TelegramBotSetup: React.FC<TelegramBotSetupProps> = ({
  settings,
  updateSettings,
  packages,
  user,
  onStartPackage,
  onNavigateToDashboard,
  onNavigateToGenerator,
  onOpenExportModal,
}) => {
  const [activeCodeLang, setActiveCodeLang] = useState<'python' | 'nodejs'>('python');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [chatInput, setChatInput] = useState<string>('');

  // Interactive Telegram Chat Simulator State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_1',
      sender: 'bot',
      text: `👋 Hello ${user.firstName}! Welcome to Self Click Bot Pro.\n\nUse the buttons below to control your automation packages or launch your personal WebApp dashboard:`,
      buttons: [
        { text: '🚀 Open WebApp Dashboard', action: 'open_dashboard' },
        { text: '📦 View My Packages', action: 'view_packages' },
        { text: '➕ Create New Package', action: 'new_package' },
      ],
      timestamp: '12:00 PM',
    },
  ]);

  const webAppUrl = window.location.origin;

  const pythonScript = `import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

BOT_TOKEN = "${settings.botToken || 'PASTE_YOUR_TELEGRAM_BOT_TOKEN_HERE'}"
WEB_APP_URL = "${webAppUrl}"

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    keyboard = [
        [
            InlineKeyboardButton(
                text="🚀 Open Self Click Dashboard", 
                web_app=WebAppInfo(url=WEB_APP_URL)
            )
        ],
        [
            InlineKeyboardButton(text="⚡ Monetag Automation", callback_data="run_monetag"),
            InlineKeyboardButton(text="⚡ Gigapub Automation", callback_data="run_gigapub")
        ],
        [
            InlineKeyboardButton(text="⚡ Direct Link", callback_data="run_direct"),
            InlineKeyboardButton(text="📊 My Stats", callback_data="stats")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    welcome_text = (
        f"🤖 **Welcome {user.first_name} to Self Click Bot!**\\n\\n"
        "Create custom packages for Monetag, Gigapub, and Direct Links with custom intervals.\\n\\n"
        "Tap below to launch your personal dashboard:"
    )
    await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode="Markdown")

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data == "run_monetag":
        await query.edit_message_text(
            "⚡ **Monetag package triggered!**\\nOpen dashboard to monitor live clicks.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text="🌐 Open Dashboard", web_app=WebAppInfo(url=WEB_APP_URL))]])
        )
    elif query.data == "stats":
        await query.edit_message_text(
            "📊 **Statistics:**\\nStatus: Active\\nDashboard synced successfully.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text="Open Dashboard", web_app=WebAppInfo(url=WEB_APP_URL))]])
        )

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    print(f"Self Click Bot running! WebApp URL: {WEB_APP_URL}")
    app.run_polling()

if __name__ == "__main__":
    main()
`;

  const nodeScript = `const { Telegraf, Markup } = require('telegraf');

const BOT_TOKEN = '${settings.botToken || 'PASTE_YOUR_TELEGRAM_BOT_TOKEN_HERE'}';
const WEB_APP_URL = '${webAppUrl}';

const bot = new Telegraf(BOT_TOKEN);

bot.start((ctx) => {
  const name = ctx.from.first_name || 'User';
  return ctx.reply(
    \`🤖 Welcome \${name} to the Self Click Telegram Bot!\\n\\nTap below to launch your personal dashboard:\`,
    Markup.inlineKeyboard([
      [Markup.button.webApp('🚀 Open Self Click Dashboard', WEB_APP_URL)],
      [
        Markup.button.callback('⚡ Monetag Clicks', 'run_monetag'),
        Markup.button.callback('⚡ Gigapub Clicks', 'run_gigapub')
      ],
      [Markup.button.callback('📊 My Stats', 'stats')]
    ])
  );
});

bot.action('run_monetag', (ctx) => {
  ctx.answerCbQuery('Starting Monetag package...');
  ctx.reply('✅ Monetag package triggered! Open dashboard to monitor clicks.');
});

bot.action('stats', (ctx) => {
  ctx.answerCbQuery();
  ctx.reply('📊 Bot status: Active and connected to WebApp.');
});

bot.launch().then(() => {
  console.log('Bot is active on Telegram!');
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
`;

  const handleCopyCode = () => {
    const code = activeCodeLang === 'python' ? pythonScript : nodeScript;
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim()) return;

    const userText = chatInput.trim();
    setChatInput('');

    const newMsgId = `usr_${Date.now()}`;
    const userMsg: ChatMessage = {
      id: newMsgId,
      sender: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);

    // Bot Response Logic
    setTimeout(() => {
      let botResponseText = '';
      let buttons: { text: string; action: string }[] | undefined = undefined;

      const lower = userText.toLowerCase();
      if (lower.includes('/start') || lower.includes('hello') || lower.includes('hi')) {
        botResponseText = `🚀 Bot active for User #${user.id}! Tap below to open your dashboard:`;
        buttons = [
          { text: '🚀 Open Dashboard', action: 'open_dashboard' },
          { text: '📦 View Packages', action: 'view_packages' },
        ];
      } else if (lower.includes('/packages') || lower.includes('package')) {
        botResponseText = packages.length === 0
          ? `You have 0 packages created yet. Tap below to create your first package:`
          : `📦 You have ${packages.length} private packages:\n` +
            packages.map((p, i) => `${i + 1}. ${p.name} (${p.network.toUpperCase()}) - ${p.completedClicks}/${p.totalClicks} clicks`).join('\n');
        buttons = [
          { text: '➕ Create Package', action: 'new_package' },
          { text: '🌐 Open Dashboard', action: 'open_dashboard' },
        ];
      } else if (lower.includes('/stats') || lower.includes('stat')) {
        const totalDone = packages.reduce((a, b) => a + b.completedClicks, 0);
        botResponseText = `📊 Your Account Stats:\n- User: ${user.firstName} (ID: ${user.id})\n- Completed Clicks: ${totalDone}\n- Active Running: ${packages.filter(p => p.status === 'running').length}\n- Estimated Earnings: $${((totalDone / 1000) * settings.cpmRate).toFixed(3)}`;
        buttons = [{ text: '🚀 Open Dashboard', action: 'open_dashboard' }];
      } else {
        botResponseText = `Command received: "${userText}". Choose an action below:`;
        buttons = [
          { text: '🚀 Open Dashboard', action: 'open_dashboard' },
          { text: '📦 View Packages', action: 'view_packages' },
        ];
      }

      setChatMessages((prev) => [
        ...prev,
        {
          id: `bot_${Date.now()}`,
          sender: 'bot',
          text: botResponseText,
          buttons,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }, 450);
  };

  const handleButtonClick = (action: string) => {
    if (action === 'open_dashboard') {
      onNavigateToDashboard();
    } else if (action === 'view_packages') {
      onNavigateToDashboard();
    } else if (action === 'new_package') {
      onNavigateToGenerator();
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Title */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Send className="w-6 h-6 text-sky-400" />
            <span>Telegram Bot Setup & Interactive Simulator</span>
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Connect your own Telegram Bot via BotFather, run tests in the chat simulator, or download ready-to-run scripts.
          </p>
        </div>

        <button
          onClick={onOpenExportModal}
          className="px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-lg transition"
        >
          <FolderDown className="w-4 h-4" />
          <span>Download Bot Files (bot.py / bot.js)</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Telegram Chat Simulator (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[560px]">
          {/* Telegram Header */}
          <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white font-bold text-sm shadow">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white leading-tight">SelfClick Pro Bot</h4>
                <span className="text-[11px] text-emerald-400 font-medium">bot • online</span>
              </div>
            </div>

            <span className="text-[10px] px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 font-mono">
              Live Simulator
            </span>
          </div>

          {/* Chat Messages Body */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-950/40 custom-scrollbar">
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs shadow-md ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-br-xs'
                      : 'bg-slate-800 text-slate-100 rounded-bl-xs border border-slate-700/60'
                  }`}
                >
                  <p className="whitespace-pre-line leading-relaxed">{msg.text}</p>
                  <span className="text-[9px] text-slate-400 mt-1 block text-right font-mono">
                    {msg.timestamp}
                  </span>
                </div>

                {/* Inline Buttons under Bot Message */}
                {msg.buttons && (
                  <div className="mt-1.5 grid grid-cols-1 sm:grid-cols-2 gap-1.5 w-full max-w-[85%]">
                    {msg.buttons.map((btn, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleButtonClick(btn.action)}
                        className="w-full text-center px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-white text-[11px] font-semibold border border-slate-700 transition active:scale-95 flex items-center justify-center gap-1"
                      >
                        <span>{btn.text}</span>
                        <ChevronRight className="w-3 h-3 text-cyan-400" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Chat Input Bar */}
          <form onSubmit={handleSendMessage} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Type /start, /packages, or a message..."
              className="flex-1 px-3 py-2 bg-slate-900 border border-slate-800 focus:border-cyan-500 rounded-xl text-xs text-white placeholder-slate-500 outline-none"
            />
            <button
              type="submit"
              className="p-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white transition active:scale-95 cursor-pointer"
              title="Send"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* Right Column: Setup Steps & Code Generator (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Step-by-Step Guide */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
            <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-cyan-400" />
              <span>Step-by-Step Telegram Bot Setup (@BotFather)</span>
            </h3>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center flex-shrink-0 text-[11px]">
                  1
                </span>
                <p>
                  Open Telegram and search for <strong className="text-white">@BotFather</strong>, then send <code className="bg-slate-950 px-1 py-0.5 rounded text-cyan-300 font-mono">/start</code>.
                </p>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center flex-shrink-0 text-[11px]">
                  2
                </span>
                <p>
                  Send <code className="bg-slate-950 px-1.5 py-0.5 rounded text-cyan-300 font-mono">/newbot</code> and follow the prompts to choose a display name and username (e.g. <code className="text-slate-400">my_selfclick_bot</code>).
                </p>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center flex-shrink-0 text-[11px]">
                  3
                </span>
                <div>
                  <p>BotFather will provide your <strong className="text-white">HTTP API Token</strong>. Enter it here (optional, used to pre-fill generated scripts):</p>
                  <div className="mt-2 flex items-center gap-2">
                    <div className="relative flex-1">
                      <Key className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
                      <input
                        type="text"
                        value={settings.botToken}
                        onChange={(e) => updateSettings({ botToken: e.target.value })}
                        placeholder="Paste Bot Token (e.g. 7123456789:AAHk...)"
                        className="w-full pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-cyan-300 placeholder-slate-600 outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center flex-shrink-0 text-[11px]">
                  4
                </span>
                <p>
                  Your WebApp URL to configure in BotFather (<code className="text-slate-300 font-mono">/newapp</code> or Menu Button): <code className="bg-slate-950 px-2 py-0.5 rounded text-emerald-400 font-mono block sm:inline mt-1 sm:mt-0 break-all">{webAppUrl}</code>
                </p>
              </div>
            </div>
          </div>

          {/* Ready-to-use Script Generator */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <Code2 className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-white">
                  Ready-to-Deploy Bot Scripts
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-xs">
                  <button
                    onClick={() => setActiveCodeLang('python')}
                    className={`px-2.5 py-1 rounded font-medium ${
                      activeCodeLang === 'python' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Python
                  </button>
                  <button
                    onClick={() => setActiveCodeLang('nodejs')}
                    className={`px-2.5 py-1 rounded font-medium ${
                      activeCodeLang === 'nodejs' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Node.js
                  </button>
                </div>

                <button
                  onClick={handleCopyCode}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
                </button>
              </div>
            </div>

            <pre className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto max-h-[260px] custom-scrollbar leading-relaxed">
              <code>{activeCodeLang === 'python' ? pythonScript : nodeScript}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
