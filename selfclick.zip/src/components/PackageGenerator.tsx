import React, { useState } from 'react';
import { 
  Sparkles, 
  Clock, 
  Repeat, 
  Link2, 
  ShieldCheck, 
  Smartphone, 
  Globe, 
  Zap, 
  Layers,
  Info,
  CheckCircle2,
  Sliders,
  AlertCircle
} from 'lucide-react';
import { AdNetwork, AdPackage, BotSettings, ClickBehavior, DeviceType, ReferrerType, TelegramUser } from '../types';
import { playClickBeep } from '../utils/audio';

interface PackageGeneratorProps {
  onSavePackage: (pkg: AdPackage) => void;
  settings: BotSettings;
  user: TelegramUser;
  onNavigateToDashboard: () => void;
}

export const PackageGenerator: React.FC<PackageGeneratorProps> = ({
  onSavePackage,
  settings,
  user,
  onNavigateToDashboard,
}) => {
  // Form State - strictly EMPTY ad ID/URL so each user must provide their own
  const [selectedNetwork, setSelectedNetwork] = useState<AdNetwork>('monetag');
  const [packageName, setPackageName] = useState<string>('');
  const [adIdOrUrl, setAdIdOrUrl] = useState<string>('');
  const [intervalSeconds, setIntervalSeconds] = useState<number>(8);
  const [totalClicks, setTotalClicks] = useState<number>(15);
  const [behavior, setBehavior] = useState<ClickBehavior>('iframe');
  const [referrer, setReferrer] = useState<ReferrerType>('telegram');
  const [device, setDevice] = useState<DeviceType>('android');
  const [enableJitter, setEnableJitter] = useState<boolean>(true);
  const [showAdvanced, setShowAdvanced] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [justGenerated, setJustGenerated] = useState<boolean>(false);

  // Network Switch Helper
  const handleNetworkSelect = (network: AdNetwork) => {
    setSelectedNetwork(network);
    setErrorMessage(null);
  };

  const networkDisplayName = selectedNetwork === 'monetag' 
    ? 'Monetag' 
    : selectedNetwork === 'gigapub' 
    ? 'Gigapub' 
    : 'Direct Link';

  const effectivePackageName = packageName.trim() || 
    `${networkDisplayName} Package (${totalClicks}x @ ${intervalSeconds}s)`;

  // Estimated total run time
  const totalEstimatedSeconds = intervalSeconds * totalClicks;
  const estimatedMins = Math.floor(totalEstimatedSeconds / 60);
  const estimatedRemainingSecs = totalEstimatedSeconds % 60;

  // Estimated CPM value
  const estimatedRevenue = ((totalClicks / 1000) * settings.cpmRate).toFixed(4);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adIdOrUrl.trim()) {
      setErrorMessage(`Please enter your ${networkDisplayName} Ad ID or Direct Link URL to continue.`);
      return;
    }

    setErrorMessage(null);

    if (settings.soundEnabled) {
      playClickBeep('start');
    }

    const newPackage: AdPackage = {
      id: `pkg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId: user.id, // Scoped to active Telegram user
      name: effectivePackageName,
      network: selectedNetwork,
      adIdOrUrl: adIdOrUrl.trim(),
      intervalSeconds: Math.max(1, intervalSeconds),
      totalClicks: Math.max(1, totalClicks),
      completedClicks: 0,
      status: 'idle',
      behavior,
      referrer,
      device,
      enableJitter,
      createdAt: Date.now(),
    };

    onSavePackage(newPackage);
    setJustGenerated(true);

    setTimeout(() => {
      onNavigateToDashboard();
    }, 600);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-amber-400" />
            <span>Create Self-Click Package</span>
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Configure your ad network, paste your custom Ad ID or Direct Link, set interval & click count.
          </p>
        </div>

        <button
          onClick={onNavigateToDashboard}
          className="text-xs sm:text-sm text-slate-400 hover:text-slate-200 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 transition"
        >
          <Layers className="w-4 h-4" />
          <span>Back to My Packages</span>
        </button>
      </div>

      <form onSubmit={handleGenerate} className="space-y-6">
        {/* Step 1: Select Ad Network */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl">
          <label className="block text-sm font-semibold text-slate-200 mb-3 flex items-center justify-between">
            <span>1. Select Ad Network</span>
            <span className="text-xs font-normal text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
              3 Networks Supported
            </span>
          </label>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            {/* Option 1: Monetag */}
            <div
              id="opt-monetag"
              onClick={() => handleNetworkSelect('monetag')}
              className={`relative cursor-pointer rounded-xl p-4 border transition-all ${
                selectedNetwork === 'monetag'
                  ? 'bg-gradient-to-b from-blue-950/60 to-slate-900 border-cyan-400 shadow-lg shadow-cyan-500/10 ring-2 ring-cyan-400/30'
                  : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 font-bold text-sm border border-blue-500/30">
                  M
                </span>
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                  selectedNetwork === 'monetag' ? 'bg-cyan-500/20 text-cyan-300' : 'bg-slate-800 text-slate-400'
                }`}>
                  Monetag
                </span>
              </div>
              <h3 className="font-bold text-white text-base">Monetag</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Direct Link, Zone ID, Vignette, In-Page Push
              </p>
              <div className="mt-3 flex items-center gap-1.5 text-[11px] text-cyan-400/90 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                Direct Link / Zone Tag
              </div>
            </div>

            {/* Option 2: Gigapub */}
            <div
              id="opt-gigapub"
              onClick={() => handleNetworkSelect('gigapub')}
              className={`relative cursor-pointer rounded-xl p-4 border transition-all ${
                selectedNetwork === 'gigapub'
                  ? 'bg-gradient-to-b from-amber-950/40 to-slate-900 border-amber-400 shadow-lg shadow-amber-500/10 ring-2 ring-amber-400/30'
                  : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 font-bold text-sm border border-amber-500/30">
                  G
                </span>
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                  selectedNetwork === 'gigapub' ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-800 text-slate-400'
                }`}>
                  Gigapub
                </span>
              </div>
              <h3 className="font-bold text-white text-base">Gigapub</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Zone ID, Publisher Script, Placement URL
              </p>
              <div className="mt-3 flex items-center gap-1.5 text-[11px] text-amber-400/90 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                Placement / Zone ID
              </div>
            </div>

            {/* Option 3: Direct Link */}
            <div
              id="opt-direct-link"
              onClick={() => handleNetworkSelect('direct_link')}
              className={`relative cursor-pointer rounded-xl p-4 border transition-all ${
                selectedNetwork === 'direct_link'
                  ? 'bg-gradient-to-b from-emerald-950/40 to-slate-900 border-emerald-400 shadow-lg shadow-emerald-500/10 ring-2 ring-emerald-400/30'
                  : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-sm border border-emerald-500/30">
                  D
                </span>
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                  selectedNetwork === 'direct_link' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-400'
                }`}>
                  Direct Link
                </span>
              </div>
              <h3 className="font-bold text-white text-base">Direct Link</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Adsterra, PopCash, Smartlink, CPA direct ad URL
              </p>
              <div className="mt-3 flex items-center gap-1.5 text-[11px] text-emerald-400/90 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                Any Custom URL
              </div>
            </div>
          </div>
        </div>

        {/* Step 2: Package Name & Custom Ad ID / URL Input */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Package Name (Optional)
            </label>
            <input
              id="input-package-name"
              type="text"
              value={packageName}
              onChange={(e) => setPackageName(e.target.value)}
              placeholder={`e.g. My ${networkDisplayName} High CPM Batch`}
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 rounded-xl text-sm text-slate-100 placeholder-slate-600 outline-none transition"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-slate-300">
                {networkDisplayName} Ad ID or Direct Link URL <span className="text-rose-400">*</span>
              </label>
              <span className="text-[11px] text-slate-500">
                Must be entered manually by you
              </span>
            </div>

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <Link2 className="w-4 h-4" />
              </div>
              <input
                id="input-ad-id-url"
                type="text"
                required
                value={adIdOrUrl}
                onChange={(e) => {
                  setAdIdOrUrl(e.target.value);
                  if (errorMessage) setErrorMessage(null);
                }}
                placeholder={
                  selectedNetwork === 'monetag' 
                    ? 'Paste your Monetag Direct Link URL or Zone ID (e.g. https://al5sm.com/4/8592031 or 8592031)' 
                    : selectedNetwork === 'gigapub' 
                    ? 'Paste your Gigapub Zone ID or placement URL (e.g. zone_7492104)' 
                    : 'Paste your custom direct ad link / smartlink URL (e.g. https://your-network.com/click?...)'
                }
                className={`w-full pl-10 pr-4 py-2.5 bg-slate-950 border rounded-xl text-sm font-mono text-cyan-300 placeholder-slate-600 outline-none transition ${
                  errorMessage ? 'border-rose-500/80 focus:ring-1 focus:ring-rose-500' : 'border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500'
                }`}
              />
            </div>

            {errorMessage ? (
              <p className="text-[11px] text-rose-400 mt-1.5 flex items-center gap-1 font-medium">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{errorMessage}</span>
              </p>
            ) : (
              <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                <Info className="w-3 h-3 text-slate-400" />
                <span>
                  {selectedNetwork === 'monetag' 
                    ? 'No automatic ID is provided. Paste your own Monetag publisher link or Zone ID.' 
                    : selectedNetwork === 'gigapub' 
                    ? 'No automatic ID is provided. Paste your own Gigapub zone or placement tag.' 
                    : 'No automatic link is provided. Paste your own CPA/Smartlink URL.'}
                </span>
              </p>
            )}
          </div>
        </div>

        {/* Step 3: Interval & Click Count */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Interval Setting */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-cyan-400" />
                <span>Interval Between Clicks</span>
              </label>
              <span className="text-xs font-bold text-cyan-400 bg-cyan-500/10 px-2.5 py-0.5 rounded-full border border-cyan-500/20 font-mono">
                {intervalSeconds} seconds
              </span>
            </div>

            <div className="mt-3">
              <input
                id="slider-interval"
                type="range"
                min={2}
                max={60}
                step={1}
                value={intervalSeconds}
                onChange={(e) => setIntervalSeconds(Number(e.target.value))}
                className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
            </div>

            {/* Quick Interval Preset Chips */}
            <div className="flex flex-wrap gap-2 mt-3">
              {[3, 5, 8, 10, 15, 30].map((sec) => (
                <button
                  key={sec}
                  type="button"
                  onClick={() => setIntervalSeconds(sec)}
                  className={`text-xs px-2.5 py-1 rounded-lg font-medium transition ${
                    intervalSeconds === sec
                      ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                      : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {sec}s
                </button>
              ))}
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              How many seconds to wait before triggering the next self-click.
            </p>
          </div>

          {/* Click Count Setting */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <Repeat className="w-4 h-4 text-emerald-400" />
                <span>Total Executions (Clicks)</span>
              </label>
              <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20 font-mono">
                {totalClicks} clicks
              </span>
            </div>

            <div className="mt-3">
              <input
                id="slider-count"
                type="range"
                min={1}
                max={200}
                step={1}
                value={totalClicks}
                onChange={(e) => setTotalClicks(Number(e.target.value))}
                className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-emerald-400"
              />
            </div>

            {/* Quick Count Preset Chips */}
            <div className="flex flex-wrap gap-2 mt-3">
              {[5, 10, 20, 50, 100].map((count) => (
                <button
                  key={count}
                  type="button"
                  onClick={() => setTotalClicks(count)}
                  className={`text-xs px-2.5 py-1 rounded-lg font-medium transition ${
                    totalClicks === count
                      ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                      : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {count}x
                </button>
              ))}
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              Total number of automated self-clicks to execute before completing.
            </p>
          </div>
        </div>

        {/* Step 4: Advanced Settings */}
        <div className="bg-slate-900/80 border border-slate-800/90 rounded-2xl overflow-hidden shadow-lg">
          <button
            type="button"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="w-full px-5 py-3.5 flex items-center justify-between text-left text-xs sm:text-sm font-semibold text-slate-300 hover:text-white transition bg-slate-950/40"
          >
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Advanced Simulation & Device Spoofing</span>
            </div>
            <span className="text-xs text-cyan-400 underline">
              {showAdvanced ? 'Hide' : 'Show'}
            </span>
          </button>

          {showAdvanced && (
            <div className="p-5 border-t border-slate-800 space-y-4 bg-slate-950/20">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Method */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                    <span>Execution Method</span>
                  </label>
                  <select
                    value={behavior}
                    onChange={(e) => setBehavior(e.target.value as ClickBehavior)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:border-cyan-500 outline-none"
                  >
                    <option value="iframe">Sandboxed Iframe (Realistic render)</option>
                    <option value="background">Background Fetch (Stealth ping)</option>
                    <option value="popup">New Window Popup (Direct visit)</option>
                  </select>
                </div>

                {/* Referrer */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Referrer Simulation</span>
                  </label>
                  <select
                    value={referrer}
                    onChange={(e) => setReferrer(e.target.value as ReferrerType)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:border-cyan-500 outline-none"
                  >
                    <option value="telegram">Telegram Mini App / Chat</option>
                    <option value="google">Google Organic Search</option>
                    <option value="facebook">Facebook Referral</option>
                    <option value="twitter">Twitter / X Referral</option>
                    <option value="direct">Direct Traffic (No Referrer)</option>
                  </select>
                </div>

                {/* Device */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-purple-400" />
                    <span>Device User-Agent</span>
                  </label>
                  <select
                    value={device}
                    onChange={(e) => setDevice(e.target.value as DeviceType)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:border-cyan-500 outline-none"
                  >
                    <option value="android">Android Mobile (Samsung/Pixel)</option>
                    <option value="ios">Apple iPhone iOS Safari</option>
                    <option value="windows">Windows 11 Chrome Desktop</option>
                    <option value="mac">Apple macOS Safari</option>
                  </select>
                </div>
              </div>

              {/* Natural Jitter Checkbox */}
              <div className="pt-2 border-t border-slate-800/80 flex items-center gap-3">
                <input
                  id="chk-jitter"
                  type="checkbox"
                  checked={enableJitter}
                  onChange={(e) => setEnableJitter(e.target.checked)}
                  className="w-4 h-4 rounded bg-slate-950 border-slate-700 text-cyan-500 focus:ring-0 cursor-pointer"
                />
                <label htmlFor="chk-jitter" className="text-xs text-slate-300 cursor-pointer select-none">
                  Natural Timer Jitter (±1-2s random variance to prevent bot detection)
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Step 5: Summary Preview Card & Generate Button */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-cyan-500/30 rounded-2xl p-5 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
                Package Summary Preview
              </span>
              <h3 className="text-base sm:text-lg font-bold text-white mt-0.5">
                {effectivePackageName}
              </h3>
            </div>

            <div className="flex items-center gap-4 text-xs">
              <div className="bg-slate-950/80 px-3 py-1.5 rounded-lg border border-slate-800">
                <span className="text-slate-400 block text-[10px]">Estimated Time</span>
                <span className="font-bold text-slate-200 font-mono">
                  {estimatedMins > 0 ? `${estimatedMins}m ` : ''}{estimatedRemainingSecs}s
                </span>
              </div>

              <div className="bg-slate-950/80 px-3 py-1.5 rounded-lg border border-slate-800">
                <span className="text-slate-400 block text-[10px]">Est. Revenue</span>
                <span className="font-bold text-emerald-400 font-mono">
                  ${estimatedRevenue}
                </span>
              </div>
            </div>
          </div>

          <button
            id="btn-generate-package"
            type="submit"
            className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:via-blue-500 hover:to-indigo-500 text-white font-bold text-base shadow-lg shadow-cyan-600/30 active:scale-[0.99] transition cursor-pointer flex items-center justify-center gap-2"
          >
            {justGenerated ? (
              <>
                <CheckCircle2 className="w-5 h-5 text-white" />
                <span>Package Created Successfully!</span>
              </>
            ) : (
              <>
                <Zap className="w-5 h-5 text-amber-300" />
                <span>⚡ Generate Package</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
