import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal, 
  Trash2, 
  Download, 
  ExternalLink, 
  Globe, 
  ShieldAlert, 
  Smartphone, 
  Monitor, 
  Zap,
  MousePointer
} from 'lucide-react';
import { ClickLog, BotSettings, AdPackage } from '../types';

interface LiveSandboxViewProps {
  logs: ClickLog[];
  onClearLogs: () => void;
  activePackage: AdPackage | null;
  settings: BotSettings;
  lastSimulatedUrl: string;
  isSimulating: boolean;
}

export const LiveSandboxView: React.FC<LiveSandboxViewProps> = ({
  logs,
  onClearLogs,
  activePackage,
  settings,
  lastSimulatedUrl,
  isSimulating,
}) => {
  const logsEndRef = useRef<HTMLDivElement>(null);
  const [deviceFrame, setDeviceFrame] = useState<'mobile' | 'desktop'>('mobile');
  const [clickVisualAnimation, setClickVisualAnimation] = useState<boolean>(false);

  // Trigger simulated cursor click animation when a click occurs
  useEffect(() => {
    if (logs.length > 0) {
      setClickVisualAnimation(true);
      const timer = setTimeout(() => setClickVisualAnimation(false), 800);
      return () => clearTimeout(timer);
    }
  }, [logs.length]);

  // Auto scroll logs
  useEffect(() => {
    if (settings.autoScrollLogs && logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, settings.autoScrollLogs]);

  const handleExportLogs = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `selfclick_logs_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleOpenDirect = () => {
    if (lastSimulatedUrl) {
      window.open(lastSimulatedUrl, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Terminal className="w-6 h-6 text-cyan-400" />
            <span>Live Sandbox & Execution Logs</span>
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">
            Real-time ad rendering sandbox viewport and live console log stream.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {lastSimulatedUrl && (
            <button
              onClick={handleOpenDirect}
              className="px-3 py-1.5 rounded-lg bg-cyan-600/20 text-cyan-300 hover:bg-cyan-600/30 border border-cyan-500/30 text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open Ad Directly</span>
            </button>
          )}

          <button
            onClick={handleExportLogs}
            disabled={logs.length === 0}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Logs</span>
          </button>

          <button
            onClick={onClearLogs}
            disabled={logs.length === 0}
            className="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 text-xs font-medium flex items-center gap-1.5 transition disabled:opacity-50"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Logs</span>
          </button>
        </div>
      </div>

      {/* Main Split Screen: Sandbox Frame + Terminal Console */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left / Top: Sandbox Viewport (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Live Viewport Sandbox
                </span>
              </div>

              {/* Device Frame Switcher */}
              <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
                <button
                  onClick={() => setDeviceFrame('mobile')}
                  className={`px-2 py-1 rounded flex items-center gap-1 ${
                    deviceFrame === 'mobile' ? 'bg-cyan-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Smartphone className="w-3 h-3" />
                  <span>Mobile</span>
                </button>
                <button
                  onClick={() => setDeviceFrame('desktop')}
                  className={`px-2 py-1 rounded flex items-center gap-1 ${
                    deviceFrame === 'desktop' ? 'bg-cyan-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Monitor className="w-3 h-3" />
                  <span>Desktop</span>
                </button>
              </div>
            </div>

            {/* Active URL bar */}
            <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 flex items-center gap-2 text-xs font-mono text-slate-400 mb-3 overflow-hidden">
              <span className="w-2 h-2 rounded-full bg-emerald-400 flex-shrink-0"></span>
              <span className="text-slate-500 flex-shrink-0">GET</span>
              <span className="truncate text-cyan-300">
                {lastSimulatedUrl || 'Waiting for package execution...'}
              </span>
            </div>

            {/* Simulated Device Screen */}
            <div className="relative mx-auto bg-slate-950 rounded-xl border border-slate-800/90 overflow-hidden shadow-inner h-[320px] flex flex-col items-center justify-center">
              {/* Virtual Cursor Animation during click */}
              {clickVisualAnimation && (
                <div className="absolute z-30 pointer-events-none transition-all duration-300 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center animate-bounce">
                  <div className="w-8 h-8 rounded-full bg-cyan-400/30 border-2 border-cyan-400 flex items-center justify-center text-cyan-200 animate-ping">
                    <MousePointer className="w-4 h-4" />
                  </div>
                  <span className="mt-1 px-2 py-0.5 rounded bg-slate-900/90 text-[10px] font-mono text-cyan-300 font-bold border border-cyan-500/40">
                    CLICK!
                  </span>
                </div>
              )}

              {lastSimulatedUrl ? (
                <div className="w-full h-full flex flex-col">
                  <div className="w-full h-full p-4 flex flex-col items-center justify-center text-center bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
                    <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-3 shadow-lg shadow-cyan-500/10">
                      <Zap className="w-7 h-7" />
                    </div>

                    <h4 className="text-sm font-bold text-white mb-1">
                      {activePackage ? activePackage.name : 'Ad Click Simulation Active'}
                    </h4>

                    <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                      Sandbox engine is safely routing ping requests, simulating device headers, and recording impression counts.
                    </p>

                    <div className="mt-4 flex flex-wrap justify-center gap-2 text-[11px] font-mono">
                      <span className="bg-slate-800 text-slate-300 px-2 py-1 rounded">
                        Network: {activePackage?.network.toUpperCase() || 'DIRECT'}
                      </span>
                      <span className="bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 px-2 py-1 rounded">
                        Status: 200 OK
                      </span>
                    </div>

                    <button
                      onClick={handleOpenDirect}
                      className="mt-4 inline-flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 underline font-medium"
                    >
                      <span>View direct landing page in new tab</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-6 text-center text-slate-500">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center mx-auto mb-2 text-slate-600">
                    <Monitor className="w-5 h-5" />
                  </div>
                  <p className="text-xs">
                    Start any package from the Dashboard to see live simulation here.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Bottom helper notice */}
          <div className="mt-4 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-400 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-cyan-400 flex-shrink-0" />
            <span>
              If ad networks enforce frame restrictions (X-Frame-Options), the background engine seamlessly proxies the impression to guarantee execution.
            </span>
          </div>
        </div>

        {/* Right / Bottom: Live Terminal & Console Logs (7 cols) */}
        <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-2xl flex flex-col h-[480px]">
          {/* Terminal Title Bar */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-3">
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block"></span>
                <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
                <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
              </div>
              <span className="text-xs font-mono font-semibold text-slate-400 ml-2">
                selfclick_engine.log
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="font-mono text-cyan-400 font-bold">{logs.length}</span>
              <span>Events Logged</span>
            </div>
          </div>

          {/* Terminal Log Output Window */}
          <div className="flex-1 overflow-y-auto font-mono text-xs space-y-2 pr-1 custom-scrollbar">
            {logs.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-600 text-center py-12">
                <Terminal className="w-8 h-8 mb-2 opacity-40" />
                <p>No execution logs yet.</p>
                <p className="text-[11px] text-slate-600 mt-1">
                  Start a package from your Dashboard to stream real-time clicks.
                </p>
              </div>
            ) : (
              logs.map((log) => (
                <div
                  key={log.id}
                  className="p-2 rounded-lg bg-slate-900/70 border border-slate-800/60 hover:border-slate-700 transition space-y-1"
                >
                  <div className="flex flex-wrap items-center justify-between gap-1 text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-500">[{log.timestamp}]</span>
                      <span className="font-bold text-cyan-400">#{log.clickNumber}/{log.totalTarget}</span>
                      <span className="text-slate-300 font-semibold">{log.packageName}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className="text-emerald-400 bg-emerald-950/80 px-1.5 py-0.2 rounded border border-emerald-500/30 text-[10px]">
                        200 OK
                      </span>
                      <span className="text-slate-400 text-[10px]">
                        {log.latencyMs}ms
                      </span>
                    </div>
                  </div>

                  <div className="text-slate-300 text-[11px] break-all">
                    {log.message}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-[10px] text-slate-500 pt-0.5 border-t border-slate-800/40">
                    <span>IP: <strong className="text-slate-400">{log.simulatedIp}</strong></span>
                    <span>•</span>
                    <span>Device: <strong className="text-slate-400">{log.device}</strong></span>
                    <span>•</span>
                    <span className="truncate max-w-[200px] text-slate-400 font-mono">
                      {log.urlPreview}
                    </span>
                  </div>
                </div>
              ))
            )}
            <div ref={logsEndRef} />
          </div>
        </div>
      </div>
    </div>
  );
};
