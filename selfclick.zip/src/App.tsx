/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { PackageGenerator } from './components/PackageGenerator';
import { LiveSandboxView } from './components/LiveSandboxView';
import { TelegramBotSetup } from './components/TelegramBotSetup';
import { ProfileView } from './components/ProfileView';
import { ExportDownloadModal } from './components/ExportDownloadModal';
import { AdPackage, ClickLog, BotSettings, TelegramUser } from './types';
import { 
  loadUserPackages, 
  saveUserPackages, 
  loadUserLogs, 
  saveUserLogs, 
  loadStoredSettings, 
  saveStoredSettings 
} from './utils/storage';
import { getInitialTelegramUser, saveCurrentUser } from './utils/telegram';
import { 
  getSimulatedUrl, 
  getRandomIp, 
  getDeviceUserAgent 
} from './utils/adHelpers';
import { playClickBeep } from './utils/audio';

export default function App() {
  // Current active Telegram User (auto-detected from Telegram WebApp or local testing profile)
  const [user, setUser] = useState<TelegramUser>(() => getInitialTelegramUser());

  // User-isolated packages & logs
  const [packages, setPackages] = useState<AdPackage[]>(() => loadUserPackages(user.id));
  const [logs, setLogs] = useState<ClickLog[]>(() => loadUserLogs(user.id));
  const [settings, setSettings] = useState<BotSettings>(() => loadStoredSettings());

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<'dashboard' | 'generator' | 'sandbox' | 'bot_setup' | 'profile'>('dashboard');

  // Export & Download modal state
  const [showExportModal, setShowExportModal] = useState<boolean>(false);

  // Execution states
  const [activePackageId, setActivePackageId] = useState<string | null>(null);
  const [countdownSeconds, setCountdownSeconds] = useState<number>(0);
  const [lastSimulatedUrl, setLastSimulatedUrl] = useState<string>('');
  const [isTelegramWebApp, setIsTelegramWebApp] = useState<boolean>(false);

  // When user switches, reload their isolated packages and logs
  const handleUserChange = (newUser: TelegramUser) => {
    setUser(newUser);
    setActivePackageId(null);
    const userPkgs = loadUserPackages(newUser.id);
    const userLgs = loadUserLogs(newUser.id);
    setPackages(userPkgs);
    setLogs(userLgs);
  };

  // Sync state to isolated per-user storage
  useEffect(() => {
    saveUserPackages(user.id, packages);
  }, [packages, user.id]);

  useEffect(() => {
    saveUserLogs(user.id, logs);
  }, [logs, user.id]);

  useEffect(() => {
    saveStoredSettings(settings);
  }, [settings]);

  // Check Telegram WebApp environment & expand viewport
  useEffect(() => {
    const tg = (window as unknown as {
      Telegram?: {
        WebApp?: {
          ready: () => void;
          expand: () => void;
          initData?: string;
        };
      };
    }).Telegram?.WebApp;

    if (tg) {
      if (tg.initData) {
        setIsTelegramWebApp(true);
      }
      try {
        tg.ready?.();
        tg.expand?.();
      } catch {
        // Safe fallback
      }
    }
  }, []);

  const updateSettings = (newSettings: Partial<BotSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const addLog = useCallback((logData: Omit<ClickLog, 'id' | 'timestamp' | 'userId'>) => {
    const newLog: ClickLog = {
      ...logData,
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: user.id,
      timestamp: new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };
    setLogs((prev) => [newLog, ...prev]);
  }, [user.id]);

  // Execute a single click for a package
  const executeClick = useCallback((pkg: AdPackage, isManual: boolean = false) => {
    const targetUrl = getSimulatedUrl(pkg.network, pkg.adIdOrUrl);
    setLastSimulatedUrl(targetUrl);

    if (settings.soundEnabled) {
      playClickBeep('click');
    }

    // Update package completed count
    const nextCompleted = pkg.completedClicks + 1;
    const isCompletedNow = nextCompleted >= pkg.totalClicks;

    setPackages((prev) =>
      prev.map((p) => {
        if (p.id === pkg.id) {
          return {
            ...p,
            completedClicks: nextCompleted,
            status: isCompletedNow ? 'completed' : p.status,
            lastRunAt: Date.now(),
          };
        }
        return p;
      })
    );

    // Record Log
    const simulatedIp = getRandomIp();
    const latency = Math.floor(Math.random() * 280) + 120;

    addLog({
      packageId: pkg.id,
      packageName: pkg.name,
      network: pkg.network,
      clickNumber: nextCompleted,
      totalTarget: pkg.totalClicks,
      status: 'success',
      message: `${isManual ? '[Manual Test Click]' : '[Auto Self-Click]'} Ping sent to ${pkg.network.toUpperCase()} (${pkg.adIdOrUrl}) - 200 OK`,
      latencyMs: latency,
      simulatedIp,
      device: pkg.device.toUpperCase(),
      urlPreview: targetUrl,
    });

    if (isCompletedNow) {
      if (settings.soundEnabled) {
        setTimeout(() => playClickBeep('complete'), 200);
      }
      addLog({
        packageId: pkg.id,
        packageName: pkg.name,
        network: pkg.network,
        clickNumber: nextCompleted,
        totalTarget: pkg.totalClicks,
        status: 'info',
        message: `🎉 All ${pkg.totalClicks} clicks completed successfully for package: ${pkg.name}!`,
        latencyMs: latency,
        simulatedIp,
        device: pkg.device.toUpperCase(),
        urlPreview: targetUrl,
      });
      setActivePackageId(null);
    }
  }, [addLog, settings.soundEnabled]);

  // Package Controls
  const handleStartPackage = (pkgId: string) => {
    const target = packages.find((p) => p.id === pkgId);
    if (!target) return;

    if (settings.soundEnabled) {
      playClickBeep('start');
    }

    // Set status to running
    setPackages((prev) =>
      prev.map((p) => {
        if (p.id === pkgId) {
          return {
            ...p,
            status: 'running',
            completedClicks: p.completedClicks >= p.totalClicks ? 0 : p.completedClicks,
          };
        }
        return p;
      })
    );

    setActivePackageId(pkgId);
    setCountdownSeconds(target.intervalSeconds);
    setLastSimulatedUrl(getSimulatedUrl(target.network, target.adIdOrUrl));

    addLog({
      packageId: target.id,
      packageName: target.name,
      network: target.network,
      clickNumber: target.completedClicks,
      totalTarget: target.totalClicks,
      status: 'info',
      message: `▶ Started package: ${target.name} (Interval: ${target.intervalSeconds}s, Target: ${target.totalClicks} clicks)`,
      latencyMs: 0,
      simulatedIp: getRandomIp(),
      device: target.device.toUpperCase(),
      urlPreview: getSimulatedUrl(target.network, target.adIdOrUrl),
    });
  };

  const handlePausePackage = (pkgId: string) => {
    setPackages((prev) =>
      prev.map((p) => {
        if (p.id === pkgId) {
          return { ...p, status: 'paused' };
        }
        return p;
      })
    );
    if (activePackageId === pkgId) {
      setActivePackageId(null);
    }
  };

  const handleResetPackage = (pkgId: string) => {
    setPackages((prev) =>
      prev.map((p) => {
        if (p.id === pkgId) {
          return { ...p, completedClicks: 0, status: 'idle' };
        }
        return p;
      })
    );
    if (activePackageId === pkgId) {
      setActivePackageId(null);
    }
  };

  const handleDeletePackage = (pkgId: string) => {
    setPackages((prev) => prev.filter((p) => p.id !== pkgId));
    if (activePackageId === pkgId) {
      setActivePackageId(null);
    }
  };

  const handleTestSingleClick = (pkg: AdPackage) => {
    executeClick(pkg, true);
  };

  const handleSavePackage = (newPkg: AdPackage) => {
    setPackages((prev) => [newPkg, ...prev]);
    setLastSimulatedUrl(getSimulatedUrl(newPkg.network, newPkg.adIdOrUrl));
  };

  // Main Tick Timer Effect
  useEffect(() => {
    const runningPkg = packages.find((p) => p.status === 'running');
    if (!runningPkg) {
      if (activePackageId) setActivePackageId(null);
      return;
    }

    if (activePackageId !== runningPkg.id) {
      setActivePackageId(runningPkg.id);
      setCountdownSeconds(runningPkg.intervalSeconds);
    }

    const intervalTimer = setInterval(() => {
      setCountdownSeconds((prevSec) => {
        if (prevSec <= 1) {
          // Time to trigger a click
          executeClick(runningPkg, false);

          // Calculate next countdown with jitter if enabled
          let nextInterval = runningPkg.intervalSeconds;
          if (runningPkg.enableJitter) {
            const jitter = Math.floor(Math.random() * 3) - 1; // -1, 0, or +1
            nextInterval = Math.max(2, nextInterval + jitter);
          }
          return nextInterval;
        }
        return prevSec - 1;
      });
    }, 1000);

    return () => clearInterval(intervalTimer);
  }, [packages, activePackageId, executeClick]);

  const activePackage = packages.find((p) => p.id === activePackageId) || null;
  const activeRunnersCount = packages.filter((p) => p.status === 'running').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-cyan-500/20 selection:text-cyan-300">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        settings={settings}
        updateSettings={updateSettings}
        isTelegramWebApp={isTelegramWebApp}
        activeRunnersCount={activeRunnersCount}
        user={user}
        onOpenExportModal={() => setShowExportModal(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16">
        {activeTab === 'dashboard' && (
          <DashboardView
            packages={packages}
            user={user}
            onStartPackage={handleStartPackage}
            onPausePackage={handlePausePackage}
            onResetPackage={handleResetPackage}
            onDeletePackage={handleDeletePackage}
            onTestSingleClick={handleTestSingleClick}
            onNavigateToGenerator={() => setActiveTab('generator')}
            onNavigateToSandbox={() => setActiveTab('sandbox')}
            onOpenExportModal={() => setShowExportModal(true)}
            settings={settings}
            activePackageId={activePackageId}
            countdownSeconds={countdownSeconds}
          />
        )}

        {activeTab === 'generator' && (
          <PackageGenerator
            onSavePackage={handleSavePackage}
            settings={settings}
            user={user}
            onNavigateToDashboard={() => setActiveTab('dashboard')}
          />
        )}

        {activeTab === 'sandbox' && (
          <LiveSandboxView
            logs={logs}
            onClearLogs={() => setLogs([])}
            activePackage={activePackage}
            settings={settings}
            lastSimulatedUrl={lastSimulatedUrl}
            isSimulating={activeRunnersCount > 0}
          />
        )}

        {activeTab === 'bot_setup' && (
          <TelegramBotSetup
            settings={settings}
            updateSettings={updateSettings}
            packages={packages}
            user={user}
            onStartPackage={handleStartPackage}
            onNavigateToDashboard={() => setActiveTab('dashboard')}
            onNavigateToGenerator={() => setActiveTab('generator')}
            onOpenExportModal={() => setShowExportModal(true)}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileView
            user={user}
            onUpdateUser={handleUserChange}
            userPackages={packages}
            cpmRate={settings.cpmRate}
          />
        )}
      </main>

      {/* Direct Export & Download Modal */}
      <ExportDownloadModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        user={user}
        packages={packages}
        logs={logs}
        settings={settings}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 text-center py-4 px-4 text-xs text-slate-500">
        <p>
          Telegram Self Click Bot Pro • Supports Monetag, Gigapub & Direct Smartlinks • High CPM Automation Engine
        </p>
      </footer>
    </div>
  );
}
