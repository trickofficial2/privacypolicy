export type AdNetwork = 'monetag' | 'gigapub' | 'direct_link';

export type ClickBehavior = 'iframe' | 'background' | 'popup';

export type ReferrerType = 'telegram' | 'google' | 'facebook' | 'direct' | 'twitter';

export type DeviceType = 'android' | 'ios' | 'windows' | 'mac';

export interface TelegramUser {
  id: string;
  firstName: string;
  lastName?: string;
  username?: string;
  photoUrl?: string;
  languageCode?: string;
  isPremium?: boolean;
  joinedAt: string;
  joinedTimestamp: number;
}

export interface AdPackage {
  id: string;
  userId: string; // Isolated per Telegram User ID
  name: string;
  network: AdNetwork;
  adIdOrUrl: string;
  intervalSeconds: number;
  totalClicks: number;
  completedClicks: number;
  status: 'idle' | 'running' | 'paused' | 'completed';
  behavior: ClickBehavior;
  referrer: ReferrerType;
  device: DeviceType;
  enableJitter: boolean;
  notes?: string;
  createdAt: number;
  lastRunAt?: number;
}

export interface ClickLog {
  id: string;
  userId: string;
  packageId: string;
  packageName: string;
  network: AdNetwork;
  timestamp: string;
  clickNumber: number;
  totalTarget: number;
  status: 'success' | 'warning' | 'error' | 'info';
  message: string;
  latencyMs: number;
  simulatedIp: string;
  device: string;
  urlPreview: string;
}

export interface BotSettings {
  language: 'en';
  botToken: string;
  cpmRate: number;
  soundEnabled: boolean;
  autoScrollLogs: boolean;
}
