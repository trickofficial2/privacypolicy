import { TelegramUser } from '../types';

const USER_SESSION_KEY = 'tg_selfclick_current_user_v2';
const USER_REGISTRY_KEY = 'tg_selfclick_registered_users_v2';

export function getInitialTelegramUser(): TelegramUser {
  // Check if running inside actual Telegram WebApp
  try {
    const tg = (window as unknown as {
      Telegram?: {
        WebApp?: {
          initDataUnsafe?: {
            user?: {
              id: number | string;
              first_name: string;
              last_name?: string;
              username?: string;
              photo_url?: string;
              language_code?: string;
              is_premium?: boolean;
            };
            auth_date?: number;
          };
          ready?: () => void;
          expand?: () => void;
        };
      };
    }).Telegram?.WebApp;

    if (tg?.initDataUnsafe?.user) {
      const u = tg.initDataUnsafe.user;
      const userId = String(u.id);
      const existingJoinDate = localStorage.getItem(`tg_user_joined_${userId}`);
      const joinedAt = existingJoinDate || new Date().toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });

      if (!existingJoinDate) {
        localStorage.setItem(`tg_user_joined_${userId}`, joinedAt);
      }

      const realUser: TelegramUser = {
        id: userId,
        firstName: u.first_name || 'Telegram',
        lastName: u.last_name || '',
        username: u.username ? `@${u.username}` : undefined,
        photoUrl: u.photo_url || undefined,
        languageCode: u.language_code || 'en',
        isPremium: !!u.is_premium,
        joinedAt,
        joinedTimestamp: Date.now(),
      };

      // Save to current session
      localStorage.setItem(USER_SESSION_KEY, JSON.stringify(realUser));
      registerUser(realUser);
      return realUser;
    }
  } catch (err) {
    console.warn('Telegram WebApp detection error', err);
  }

  // If outside Telegram (e.g. testing in desktop browser), check saved user or create default
  try {
    const saved = localStorage.getItem(USER_SESSION_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch {
    // fallback
  }

  // Default demo user for browser preview
  const defaultUser: TelegramUser = {
    id: '689210452',
    firstName: 'Alex',
    lastName: 'Rider',
    username: '@alex_traffic',
    photoUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    languageCode: 'en',
    isPremium: true,
    joinedAt: new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }),
    joinedTimestamp: Date.now(),
  };

  localStorage.setItem(USER_SESSION_KEY, JSON.stringify(defaultUser));
  registerUser(defaultUser);
  return defaultUser;
}

export function saveCurrentUser(user: TelegramUser): void {
  localStorage.setItem(USER_SESSION_KEY, JSON.stringify(user));
  registerUser(user);
}

function registerUser(user: TelegramUser): void {
  try {
    const raw = localStorage.getItem(USER_REGISTRY_KEY);
    const registry: TelegramUser[] = raw ? JSON.parse(raw) : [];
    const exists = registry.some((u) => u.id === user.id);
    if (!exists) {
      registry.push(user);
      localStorage.setItem(USER_REGISTRY_KEY, JSON.stringify(registry));
    }
  } catch {
    // ignore
  }
}

export function getRegisteredUsers(): TelegramUser[] {
  try {
    const raw = localStorage.getItem(USER_REGISTRY_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}
