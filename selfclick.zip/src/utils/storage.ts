import { AdPackage, ClickLog, BotSettings } from '../types';

const SETTINGS_KEY = 'tg_selfclick_settings_v2';

export const defaultSettings: BotSettings = {
  language: 'en',
  botToken: '',
  cpmRate: 1.85,
  soundEnabled: true,
  autoScrollLogs: true,
};

export function loadUserPackages(userId: string): AdPackage[] {
  try {
    const raw = localStorage.getItem(`tg_packages_${userId}`);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveUserPackages(userId: string, packages: AdPackage[]): void {
  try {
    localStorage.setItem(`tg_packages_${userId}`, JSON.stringify(packages));
  } catch (err) {
    console.error('Failed to save user packages', err);
  }
}

export function loadUserLogs(userId: string): ClickLog[] {
  try {
    const raw = localStorage.getItem(`tg_logs_${userId}`);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveUserLogs(userId: string, logs: ClickLog[]): void {
  try {
    const trimmed = logs.slice(0, 100);
    localStorage.setItem(`tg_logs_${userId}`, JSON.stringify(trimmed));
  } catch (err) {
    console.error('Failed to save user logs', err);
  }
}

export function loadStoredSettings(): BotSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return defaultSettings;
    return { ...defaultSettings, ...JSON.parse(raw) };
  } catch {
    return defaultSettings;
  }
}

export function saveStoredSettings(settings: BotSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings', err);
  }
}
