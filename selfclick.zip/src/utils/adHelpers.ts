import { AdNetwork, DeviceType, ReferrerType } from '../types';

export function getSimulatedUrl(network: AdNetwork, adIdOrUrl: string): string {
  if (adIdOrUrl.startsWith('http://') || adIdOrUrl.startsWith('https://')) {
    return adIdOrUrl;
  }

  // If raw ID provided:
  if (network === 'monetag') {
    return `https://al5sm.com/4/${encodeURIComponent(adIdOrUrl.replace(/\D/g, '') || '8592031')}`;
  }
  if (network === 'gigapub') {
    return `https://gigapub.adnetwork.tech/serve?zone=${encodeURIComponent(adIdOrUrl)}&type=direct`;
  }
  return `https://direct-ads.network/click?tag=${encodeURIComponent(adIdOrUrl)}`;
}

export function getRandomIp(): string {
  const subnets = [
    '103.145.74.',
    '182.160.118.',
    '202.134.12.',
    '119.30.38.',
    '27.147.202.',
    '103.230.106.',
    '45.112.58.',
  ];
  const subnet = subnets[Math.floor(Math.random() * subnets.length)];
  const host = Math.floor(Math.random() * 253) + 2;
  return `${subnet}${host}`;
}

export function getDeviceUserAgent(device: DeviceType): string {
  switch (device) {
    case 'android':
      return 'Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36 Telegram-Android/10.9.1';
    case 'ios':
      return 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Telegram-iOS/10.9.1';
    case 'windows':
      return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
    case 'mac':
      return 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15';
    default:
      return 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36';
  }
}

export function getReferrerUrl(referrer: ReferrerType): string {
  switch (referrer) {
    case 'telegram':
      return 'https://web.telegram.org/a/';
    case 'google':
      return 'https://www.google.com/search?q=online+rewards+portal';
    case 'facebook':
      return 'https://l.facebook.com/l.php?u=https%3A%2F%2Fad-link.com';
    case 'twitter':
      return 'https://t.co/promo_click';
    case 'direct':
    default:
      return 'direct_traffic';
  }
}

export function formatTimeRemaining(seconds: number): string {
  if (seconds <= 0) return '0s';
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  if (mins > 0) {
    return `${mins}m ${secs}s`;
  }
  return `${secs}s`;
}
